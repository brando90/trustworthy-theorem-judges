# Rate theorem coverage

Read Rating_Instructions.md. In each assigned folder, read the Python source and the gold Lean theorem statements, then rate each candidate under agent_lean. The files in gold_lean_dependencies, when present, support the reference.

Open ratings.csv in a spreadsheet editor. Enter your rater ID and final_score_0_5 for each assigned file. Keep the item IDs and filenames intact. Record any reference problem in problem_note. Return your completed CSV privately to Brando.

## Assistance and reference problems

You may use artificial intelligence (AI) for localized help with parts of the rating task. You may not have AI do the whole rating task for you. For example, you can ask for help understanding a particular theorem or checking a specific point you are unsure about, rather than asking AI to rate all the files for you. You remain responsible for the final rating.

Rate independently, keep the system identities and other people's ratings hidden, and do not discuss particular items with other raters before the round closes. If you use a tool, briefly note the kind of localized help in `problem_note`; do not paste private conversations or model-generated ratings into the sheet.

Specifications of real code are often ambiguous, for example what to return on an empty list when the Python raises an error. When a reference picks a reasonable convention for such a case, rate with your own judgment and note your reasoning in `rationale`; some variation between raters is expected. Only if something is actually incorrect (a reference theorem that is false, or one that contradicts the Python on an input the Python accepts) put the smallest concrete example in `problem_note`, leave that score blank and email brandojazz@gmail.com. Every reference was checked on 10-11-2026, so we don't expect this.

This replaces earlier, more restrictive descriptions of AI assistance. The scoring rubric, score scale, blind ordering, candidate files and reference files are unchanged.
