# Start your human ratings

This packet has 6 candidate files. Form revision: 11-11-2026.

1. Open ratings.csv for Slava Naprienko. Return the completed CSV to brandojazz@gmail.com.
2. Read RATING_FORM_GUIDE.md for the shared warm-up/main fields and assistance policy. It supersedes older submission links and assistance wording.
3. Read human_judgements_prompt.md for the unchanged 0–5 scoring rubric. Read Python source, gold theorem statements and candidate theorem statements in each task folder. Rate statements, not proofs.
4. Fill one row per candidate in your assigned form. Use AI for localized assistance. Make the comparison, choose the score and answer the attestation yourself. Please estimate minutes and confidence; a one-sentence rationale is preferred but optional. Add a problem note if needed.

Save and return the completed ratings.csv; you do not need a Google Sheet.
