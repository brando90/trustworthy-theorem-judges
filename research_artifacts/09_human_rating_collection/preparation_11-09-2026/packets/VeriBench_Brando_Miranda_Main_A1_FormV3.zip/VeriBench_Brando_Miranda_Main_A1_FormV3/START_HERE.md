# Start your human ratings

This packet has 125 candidate files. Form revision: 11-11-2026.

1. Open the personal Google Sheet in YOUR_RATING_SHEET.txt. Use that existing sheet; no copy is needed.
2. Read RATING_FORM_GUIDE.md for the shared warm-up/main fields and assistance policy. It supersedes older submission links and assistance wording.
3. Read Rating_Instructions.md for the unchanged 0–5 scoring rubric. Read Python source, gold theorem statements and candidate theorem statements in each task folder. Rate statements, not proofs.
4. Fill one row per candidate in your Google Sheet. Model assistance for localized questions is encouraged. Record the help and answer the attestation yourself.

The included ratings.csv is a blank form with the same columns; the personal Google Sheet is your return route.
