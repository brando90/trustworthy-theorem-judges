# Start here: the warm-up set (about 30-45 minutes)

**What this is:** six short agent Lean files from an earlier rating round, in two task folders (`W01`, `W02`).
Everyone on the panel rates the same six files first. It is practice with the real instructions, and it shows
how each person uses the 0-5 scale. Rate exactly as you will rate your task folders afterwards.

## Steps

1. **Open your rating sheet:** the link is in `YOUR_RATING_SHEET.txt`, next to this file. It is shared with you
   as an editor and already has your rater code filled in. Type straight into it; it saves as you go.
2. **Read the rules once:** `human_judgements_prompt.md`. Ignore its own Google Sheet link; use your sheet from step 1.
3. **For each folder (`W01`, then `W02`):**
   - read the Python program in `python_source/`;
   - read the reference Lean file in `gold_lean/`: its theorem statements are what "full coverage" means;
   - rate each agent file in `agent_lean/` (three per folder) on statement coverage only, not proofs:
     the A-D checklist, a 0-5 base score, the spam adjustment, and the lower score when unsure.
4. **Fill one row per file in your sheet:**
   - `final_score_0_5` is required;
   - `minutes_spent`: roughly how many minutes that file took you (include reading time for the folder in its first file);
   - `lean_familiarity`: `none`, `some` or `fluent` (same value on every row);
   - everything else (A-D, base score, confidence, rationale, problem_note) is optional but helpful.
5. **That's it:** when every row has a final score, you're done. There is nothing to copy, share or send; we
   read your sheet directly. Please don't change it after you finish; if you need to, email brandojazz@gmail.com.

## Good to know

- **No Lean expertise needed:** you compare theorem statements; you never write or check proofs.
- **Your sheet is personal:** it is shared only with you, so please don't forward the link. If Google asks you to
  request access, switch to the Google account named in `YOUR_RATING_SHEET.txt`.
- **Next:** once all six rows have a final score, your task folders (set N) arrive within a working day.
- **Questions:** brandojazz@gmail.com.

**Rules:** rate on your own, with no AI tools, and do not look up earlier ratings of these files.
Do not discuss the files with other raters until everyone is done.
