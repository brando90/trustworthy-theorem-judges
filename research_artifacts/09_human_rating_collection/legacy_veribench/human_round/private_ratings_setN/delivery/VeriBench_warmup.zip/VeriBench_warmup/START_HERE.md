# Start here: the warm-up set (about 30-45 minutes)

**What this is:** six short agent Lean files from an earlier rating round, in two task folders (`W01`, `W02`).
Everyone on the panel rates the same six files first. It is practice with the real instructions, and it shows
how each person uses the 0-5 scale. Rate exactly as you will rate your task folders afterwards.

## Steps

1. **Read the rules once:** `human_judgements_prompt.md`. Ignore its Google Sheet link; use `rating_sheet.csv`.
2. **For each folder (`W01`, then `W02`):**
   - read the Python program in `python_source/`;
   - read the reference Lean file in `gold_lean/`: its theorem statements are what "full coverage" means;
   - rate each agent file in `agent_lean/` (three per folder) on statement coverage only, not proofs:
     the A-D checklist, a 0-5 base score, the spam adjustment, and the lower score when unsure.
3. **Fill one row per file** in `rating_sheet.csv`:
   - `rater_id`: your name or initials; `final_score_0_5` is required;
   - `minutes_spent`: roughly how many minutes that file took you (include reading time for the folder in its first file);
   - `lean_familiarity`: `none`, `some` or `fluent` (same value on every row);
   - everything else (A-D, base score, confidence, rationale, problem_note) is optional but helpful.
4. **Email the sheet back to Brando.** Your task folders follow.

**Rules:** rate on your own, with no AI tools, and do not look up earlier ratings of these files.
Do not discuss the files with other raters until everyone is done.
